// MyDebugPlugin.cpp : ���� DLL Ӧ�ó���ĵ���������
//

#include "stdafx.h"
#include "windows.h"
#include <winternl.h>
#include <stdlib.h>
#include <atlstr.h>
#include <TlHelp32.h>

#pragma comment(lib,"ntdll.lib")

LPVOID m_ProcessHandle = nullptr;
LPVOID m_ThreadHandle = nullptr;

typedef struct _UNICODE_STR
{
	USHORT Length;
	USHORT MaximumLength;
	PWSTR pBuffer;
} UNICODE_STR, *PUNICODE_STR;
typedef struct _PEB_FREE_BLOCK // 2 elements, 0x8 bytes
{
	struct _PEB_FREE_BLOCK * pNext;
	DWORD dwSize;
} PEB_FREE_BLOCK, *PPEB_FREE_BLOCK;
typedef struct _MYPEB // 65 elements, 0x210 bytes
{
	BYTE bInheritedAddressSpace;
	BYTE bReadImageFileExecOptions;
	BYTE bBeingDebugged;
	BYTE bSpareBool;
	LPVOID lpMutant;
	LPVOID lpImageBaseAddress;
	PPEB_LDR_DATA pLdr;
	LPVOID lpProcessParameters;
	LPVOID lpSubSystemData;
	LPVOID lpProcessHeap;
	PRTL_CRITICAL_SECTION pFastPebLock;
	LPVOID lpFastPebLockRoutine;
	LPVOID lpFastPebUnlockRoutine;
	DWORD dwEnvironmentUpdateCount;
	LPVOID lpKernelCallbackTable;
	DWORD dwSystemReserved;
	DWORD dwAtlThunkSListPtr32;
	PPEB_FREE_BLOCK pFreeList;
	DWORD dwTlsExpansionCounter;
	LPVOID lpTlsBitmap;
	DWORD dwTlsBitmapBits[2];
	LPVOID lpReadOnlySharedMemoryBase;
	LPVOID lpReadOnlySharedMemoryHeap;
	LPVOID lpReadOnlyStaticServerData;
	LPVOID lpAnsiCodePageData;
	LPVOID lpOemCodePageData;
	LPVOID lpUnicodeCaseTableData;
	DWORD dwNumberOfProcessors;
	DWORD dwNtGlobalFlag;
	LARGE_INTEGER liCriticalSectionTimeout;
	DWORD dwHeapSegmentReserve;
	DWORD dwHeapSegmentCommit;
	DWORD dwHeapDeCommitTotalFreeThreshold;
	DWORD dwHeapDeCommitFreeBlockThreshold;
	DWORD dwNumberOfHeaps;
	DWORD dwMaximumNumberOfHeaps;
	LPVOID lpProcessHeaps;
	LPVOID lpGdiSharedHandleTable;
	LPVOID lpProcessStarterHelper;
	DWORD dwGdiDCAttributeList;
	LPVOID lpLoaderLock;
	DWORD dwOSMajorVersion;
	DWORD dwOSMinorVersion;
	WORD wOSBuildNumber;
	WORD wOSCSDVersion;
	DWORD dwOSPlatformId;
	DWORD dwImageSubsystem;
	DWORD dwImageSubsystemMajorVersion;
	DWORD dwImageSubsystemMinorVersion;
	DWORD dwImageProcessAffinityMask;
	DWORD dwGdiHandleBuffer[34];
	LPVOID lpPostProcessInitRoutine;
	LPVOID lpTlsExpansionBitmap;
	DWORD dwTlsExpansionBitmapBits[32];
	DWORD dwSessionId;
	ULARGE_INTEGER liAppCompatFlags;
	ULARGE_INTEGER liAppCompatFlagsUser;
	LPVOID lppShimData;
	LPVOID lpAppCompatInfo;
	UNICODE_STR usCSDVersion;
	LPVOID lpActivationContextData;
	LPVOID lpProcessAssemblyStorageMap;
	LPVOID lpSystemDefaultActivationContextData;
	LPVOID lpSystemAssemblyStorageMap;
	DWORD dwMinimumStackCommit;
} MYPEB, *PMYPEB;
typedef struct _PROCESS_BASIC_INFORMATION32 {
	NTSTATUS ExitStatus;
	UINT32 PebBaseAddress;
	UINT32 AffinityMask;
	UINT32 BasePriority;
	UINT32 UniqueProcessId;
	UINT32 InheritedFromUniqueProcessId;
} PROCESS_BASIC_INFORMATION32;


DWORD GetPebAddress(HANDLE nHandle)
{
	PROCESS_BASIC_INFORMATION32 pbi = { 0 };
	NTSTATUS Status = NtQueryInformationProcess(
		nHandle,
		ProcessBasicInformation,
		&pbi,
		sizeof(pbi),
		NULL);

	if (NT_SUCCESS(Status))
	{
		MYPEB* Peb = (MYPEB*)malloc(sizeof(MYPEB));
		ReadProcessMemory(nHandle, (PVOID)pbi.PebBaseAddress, (MYPEB*)Peb, sizeof(MYPEB), NULL);
		return pbi.PebBaseAddress;
	}
	return 0;
}
DWORD GetApiAddress(CString nApi)
{
	HMODULE nHandle = nullptr;
	DWORD nAddress = 0;

	nHandle = GetModuleHandle(TEXT("kernel32.dll"));
	nAddress = (DWORD)GetProcAddress(nHandle, CStringA(nApi));
	if (nAddress)return nAddress;
	FreeLibrary(nHandle);

	nHandle = GetModuleHandle(TEXT("user32.dll"));
	nAddress = (DWORD)GetProcAddress(nHandle, CStringA(nApi));
	if (nAddress)return nAddress;
	FreeLibrary(nHandle);

	nHandle = GetModuleHandle(TEXT("gdi32.dll"));
	nAddress = (DWORD)GetProcAddress(nHandle, CStringA(nApi));
	if (nAddress)return nAddress;
	FreeLibrary(nHandle);

	nHandle = GetModuleHandle(TEXT("ntdll.dll"));
	nAddress = (DWORD)GetProcAddress(nHandle, CStringA(nApi));
	if (nAddress)return nAddress;
	FreeLibrary(nHandle);

	return 0;
}
DWORD GetProcessThreadId(DWORD nPid)
{
	BOOL nRet;
	DWORD nIndex = 0;
	THREADENTRY32 nThread;

	nThread.dwSize = sizeof(THREADENTRY32);
	HANDLE nSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, nPid);

	nRet = Thread32First(nSnapShot, &nThread);
	while (nRet)
	{
		if (nThread.th32OwnerProcessID == nPid)
		{
			CloseHandle(nSnapShot);
			return nThread.th32ThreadID;
		}
		nRet = Thread32Next(nSnapShot, &nThread);
	}
	CloseHandle(nSnapShot);
	return NULL;
}
VOID WriteMemoryByte(DWORD nAddress, BYTE nValue)
{
	DWORD nOldProtect;
	DWORD nWriteSize;
	VirtualProtectEx(m_ProcessHandle, (LPVOID)nAddress, 1, PAGE_EXECUTE_READWRITE, &nOldProtect);
	WriteProcessMemory(m_ProcessHandle, (LPVOID)nAddress, &nValue, 1, &nWriteSize);
	VirtualProtectEx(m_ProcessHandle, (LPVOID)nAddress, 1, nOldProtect, &nOldProtect);
}
VOID ReadMemoryBytes(DWORD nAddress, LPBYTE nValue, DWORD nLen)
{
	DWORD nReadSize;
	ReadProcessMemory(m_ProcessHandle, (LPCVOID)nAddress, nValue, nLen, &nReadSize);
}
VOID WriteMemoryBytes(DWORD nAddress, LPBYTE nValue, DWORD nLen)
{
	DWORD nOldProtect;
	DWORD nWriteSize;
	VirtualProtectEx(m_ProcessHandle, (LPVOID)nAddress, nLen, PAGE_EXECUTE_READWRITE, &nOldProtect);
	WriteProcessMemory(m_ProcessHandle, (LPVOID)nAddress, nValue, nLen, &nWriteSize);
	VirtualProtectEx(m_ProcessHandle, (LPVOID)nAddress, nLen, nOldProtect, &nOldProtect);
}

VOID AntiPeb()
{
	DWORD nPebAddress = GetPebAddress(m_ProcessHandle);
	WriteMemoryByte(nPebAddress + 2, '\0');//BeingDebugged

	WriteMemoryByte(nPebAddress + 0x68, '\0');//Global
}
VOID AntiNtQueryInformationProcess()
{

	DWORD nExplorerPID;
	DWORD nSSDT;
	DWORD nApiAddress;
	DWORD nHookCodeAddress;
	BYTE nJmpCode[5] = { 0xe9,0x0,0x0 ,0x0 ,0x0 };
	BYTE nHookCode[] = {
		139,68,36,8,131,248,7,117,13,139,68,36,12,199,0,0,0,0,0,194,20,0,131,
		248,30,117,13,139,68,36,12,199,0,0,0,0,0,194,20,0,131,248,31,117,13,139,
		68,36,12,199,0,1,0,0,0,194,20,0,131,248,35,117,13,139,68,36,12,199,0,0,0,0,0,
		194,20,0,131,248,0,117,16,139,68,36,12,131,192,20,199,0,136,136,136,136,194,20,
		0,184,22,0,0,0,104,237,250,163,119,195 };
	nApiAddress = GetApiAddress(TEXT("NtQueryInformationProcess"));
	nHookCodeAddress = (DWORD)VirtualAllocEx(m_ProcessHandle, NULL, 1, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	ReadMemoryBytes(nApiAddress + 1, (LPBYTE)&nSSDT, 4);
	GetWindowThreadProcessId(::FindWindow(L"Progman", NULL), &nExplorerPID);

	*(DWORD*)(nJmpCode + 1) = nHookCodeAddress - nApiAddress - 5;
	*(DWORD*)(nHookCode + _countof(nHookCode) - 5) = nApiAddress + 5;
	*(DWORD*)(nHookCode + _countof(nHookCode) - 10) = nSSDT;
	*(DWORD*)(nHookCode + 90) = nExplorerPID;

	WriteMemoryBytes(nHookCodeAddress, nHookCode, _countof(nHookCode));

	WriteMemoryBytes(nApiAddress, nJmpCode, _countof(nJmpCode));


	//000A0000 - 8B 44 24 08 - mov eax, [esp + 08]
	//000A0004 - 83 F8 07 - cmp eax, 07
	//000A0007 - 75 0D - jne 000A0016
	//000A0009 - 8B 44 24 0C - mov eax, [esp + 0C]
	//000A000D - C7 00 00000000 - mov[eax], 00000000
	//000A0013 - C2 1400 - ret 0014
	//000A0016 - 83 F8 1E - cmp eax, 1E
	//000A0019 - 75 0D - jne 000A0028
	//000A001B - 8B 44 24 0C - mov eax, [esp + 0C]
	//000A001F - C7 00 00000000 - mov[eax], 00000000
	//000A0025 - C2 1400 - ret 0014
	//000A0028 - 83 F8 1F - cmp eax, 1F
	//000A002B - 75 0D - jne 000A003A
	//000A002D - 8B 44 24 0C - mov eax, [esp + 0C]
	//000A0031 - C7 00 01000000 - mov[eax], 00000001
	//000A0037 - C2 1400 - ret 0014
	//000A003A - 83 F8 23 - cmp eax, 23
	//000A003D - 75 0D - jne 000A004C
	//000A003F - 8B 44 24 0C - mov eax, [esp + 0C]
	//000A0043 - C7 00 00000000 - mov[eax], 00000000
	//000A0049 - C2 1400 - ret 0014
	//000A004C - 83 F8 00 - cmp eax, 00
	//000A004F - 75 10 - jne 000A0061
	//000A0051 - 8B 44 24 0C - mov eax, [esp + 0C]
	//000A0055 - 83 C0 14 - add eax, 14
	//000A0058 - C7 00 88888888 - mov[eax], 88888888
	//000A005E - C2 1400 - ret 0014
	//000A0061 - B8 16000000 - mov eax, 00000016
	//000A0066 - 68 EDFAA377 - push ntdll.ZwQueryInformationProcess + 5
	//000A006B - C3 - ret

}
VOID AntiZwSetInformationThread()
{
	DWORD nApiAddress;
	nApiAddress = GetApiAddress(TEXT("ZwSetInformationThread"));
	BYTE nHookCode[] = { 0xC2,0x10,0x00 };
	WriteMemoryBytes(nApiAddress, nHookCode, _countof(nHookCode));

	//ntdll.ZwSetInformationThread - B8 0A000000 - mov eax, 0000000A
	//ntdll.ZwSetInformationThread + 5 - 33 C9 - xor ecx, ecx
	//ntdll.ZwSetInformationThread + 7 - 8D 54 24 04 - lea edx, [esp + 04]
	//ntdll.ZwSetInformationThread + B - 64 FF 15 C0000000 - call fs : [000000C0]
	//ntdll.ZwSetInformationThread + 12 - 83 C4 04 - add esp, 04
	//ntdll.ZwSetInformationThread + 15 - C2 1000 - ret 0010

}

//��ʼ������ӿڣ���ѡ��
CHAR* WINAPI InitPlugin()
{
	char * nRet = "MyDebug �������Բ��";
	return nRet;
}

//��������ʱ���õĽӿ�(�����������������᷵�ؽ���id���߳�id)
VOID WINAPI CreateProcessEvent(DWORD m_Pid, DWORD m_Tid)
{
	//�򿪽��̾��
	m_ProcessHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, m_Pid);
	if (m_ProcessHandle == nullptr)MessageBox(NULL, TEXT("C++Plugin�򿪽���ʧ�ܣ�"), TEXT("��ʾ"), MB_ICONERROR);

	//���߳̾��
	m_Tid = GetProcessThreadId(m_Pid);
	m_ThreadHandle = OpenThread(THREAD_ALL_ACCESS, FALSE, m_Tid);
	if (m_ProcessHandle == nullptr)MessageBox(NULL, TEXT("C++Plugin���߳�ʧ�ܣ�"), TEXT("��ʾ"), MB_ICONERROR);

	AntiPeb();							//����PEB
	AntiNtQueryInformationProcess();	//HOOK����
	AntiZwSetInformationThread();		//HOOK����
}

//�����߳�ʱ���õĽӿ�
VOID WINAPI CreateThreadEvent(HANDLE nHandle, DWORD nThreadLocalBase)
{

}